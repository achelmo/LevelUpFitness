package edu.csis343.levelupfitness;

public class LoginActivityModel {

    //Define login data and how it will be used with the controller class

}
